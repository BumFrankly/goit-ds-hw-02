from faker import Faker
import sqlite3

fake = Faker()

try:
    # Connect to the database
    conn = sqlite3.connect('task_manager.db')
    cursor = conn.cursor()

    # Create tables
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fullname VARCHAR(100),
        email VARCHAR(100) UNIQUE
    )
    ''')
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS status (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name VARCHAR(50) UNIQUE
    )
    ''')
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title VARCHAR(100),
        description TEXT,
        status_id INTEGER,
        user_id INTEGER,
        FOREIGN KEY(status_id) REFERENCES status(id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    )
    ''')  # Додаємо налаштування каскадного видалення

    conn.commit()

    # users
    for _ in range(10):
        fullname = fake.name()
        email = fake.email()
        cursor.execute("INSERT INTO users (fullname, email) VALUES (?,?)", (fullname, email))
        conn.commit()

    # status
    statuses = ['new', 'in progress', 'completed']
    for status in statuses:
        cursor.execute("INSERT INTO status (name) VALUES (?)", (status,))
        conn.commit()

    # tasks
    for _ in range(20):
        title = fake.sentence()
        description = fake.paragraph()
        status_id = fake.random_int(min=1, max=len(statuses))
        user_id = fake.random_int(min=1, max=10)
        cursor.execute("INSERT INTO tasks (title, description, status_id, user_id) VALUES (?,?,?,?)", (title, description, status_id, user_id))
        conn.commit()

except sqlite3.Error as e:
    print("SQLite error:", e)

finally:
    # Close the connection
    conn.close()

