import sqlite3

def connect_to_database(task_manager):
    """Підключення до бази даних"""
    conn = sqlite3.connect('task_manager.db')
    return conn

def select_tasks_by_user_id(conn, user_id):
  """
  Отримати всі завдання певного користувача.

  Args:
    conn: Об'єкт підключення до бази даних.
    user_id: Ідентифікатор користувача.

  Returns:
    Список словників, де кожен словник містить інформацію про завдання.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("SELECT title, description FROM tasks WHERE user_id = %s;", (user_id,))
  rows = cur.fetchall()
  cur.close()
  return rows

def select_tasks_by_status(conn, status_name):
  """
  Вибрати завдання за певним статусом.

  Args:
    conn: Об'єкт підключення до бази даних.
    status_name: Назва статусу.

  Returns:
    Список словників, де кожен словник містить інформацію про завдання.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("SELECT title, description FROM tasks WHERE status_id IN (SELECT id FROM status WHERE name = %s)", (status_name,))
  rows = cur.fetchall()
  cur.close()
  return rows

def update_task_status(conn, task_id, new_status):
  """
  Оновити статус конкретного завдання.

  Args:
    conn: Об'єкт підключення до бази даних.
    task_id: Ідентифікатор завдання.
    new_status: Новий статус завдання.
  """
  cur = conn.cursor()
  cur.execute("UPDATE tasks SET status_id = (SELECT id FROM status WHERE name = %s) WHERE id = %s", (new_status, task_id))
  cur.close()
  conn.commit()

def get_users_without_tasks(conn):
  """
  Отримати список користувачів, які не мають жодного завдання.

  Args:
    conn: Об'єкт підключення до бази даних.

  Returns:
    Список словників, де кожен словник містить інформацію про користувача.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("SELECT * FROM users WHERE id NOT IN (SELECT user_id FROM tasks)")
  rows = cur.fetchall()
  cur.close()
  return rows

def add_task(conn, user_id, title, description):
  """
  Додати нове завдання для конкретного користувача.

  Args:
    conn: Об'єкт підключення до бази даних.
    user_id: Ідентифікатор користувача.
    title: Назва завдання.
    description: Опис завдання.
  """
  cur = conn.cursor()
  cur.execute("INSERT INTO tasks (user_id, title, description) VALUES (%s, %s, %s)", (user_id, title, description))
  cur.close()
  conn.commit()

def get_unfinished_tasks(conn):
  """
  Отримати всі завдання, які ще не завершено.

  Args:
    conn: Об'єкт підключення до бази даних.

  Returns:
    Список словників, де кожен словник містить інформацію про завдання.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("SELECT * FROM tasks WHERE status_id != (SELECT id FROM status WHERE name = 'завершено')")
  rows = cur.fetchall()
  cur.close()
  return rows

def delete_task(conn, task_id):
  """
  Видалити конкретне завдання.

  Args:
    conn: Об'єкт підключення до бази даних.
    task_id: Ідентифікатор завдання.
  """
  cur = conn.cursor()
  cur.execute("DELETE FROM tasks WHERE id = %s", (task_id,))
  cur.close()
  conn.commit()

def find_users_by_email(conn, email):
  """
  Знайти користувачів з певною електронною поштою.

  Args:
    conn: Об'єкт підключення до бази даних.
    email: Електронна пошта користувача.

  Returns:
    Список словників, де кожен словник містить інформацію про користувача.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("SELECT * FROM users WHERE email LIKE %s", (f"%{email}%",))
  rows = cur.fetchall()
  cur.close()
  return rows

def update_user_name(conn, user_id, new_name):
  """
  Оновити ім'я користувача.

  Args:
    conn: Об'єкт підключення до бази даних.
    user_id: Ідентифікатор користувача.
    new_name: Нове ім'я користувача.
  """
  cur = conn.cursor()
  cur.execute("UPDATE users SET name = %s WHERE id = %s", (new_name, user_id))
  cur.close()
  conn.commit()

def get_task_count_by_status(conn):
  """
  Отримати кількість завдань для кожного статусу.

  Args:
    conn: Об'єкт підключення до бази даних.

  Returns:
    Список кортежів, де перший елемент - назва статусу, а другий - кількість завдань.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("SELECT s.name, COUNT(t.id) AS task_count FROM tasks t JOIN status s ON t.status_id = s.id GROUP BY s.name")
  rows = cur.fetchall()
  cur.close()
  return rows

def get_tasks_by_user_domain(conn, domain):
  """
  Отримати завдання, я

кі призначені користувачам з певної доменної частини електронної пошти.

  Args:
    conn: Об'єкт підключення до бази даних.
    domain: Домен електронної пошти (наприклад, 'example.com').

  Returns:
    Список словників, де кожен словник містить інформацію про завдання.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("""
  SELECT t.* 
  FROM tasks t
  JOIN users u ON t.user_id = u.id
  WHERE u.email LIKE %s""", (f"%@{domain}%",))
  rows = cur.fetchall()
  cur.close()
  return rows

def get_tasks_without_description(conn):
  """
  Отримати список завдань, що не мають опису.

  Args:
    conn: Об'єкт підключення до бази даних.

  Returns:
    Список словників, де кожен словник містить інформацію про завдання.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("SELECT * FROM tasks WHERE description IS NULL")
  rows = cur.fetchall()
  cur.close()
  return rows

def get_users_with_in_progress_tasks(conn):
  """
  Вибрати користувачів та їхні завдання, які є у статусі 'in progress'.

  Args:
    conn: Об'єкт підключення до бази даних.

  Returns:
    Список словників, де кожен словник містить інформацію про користувача та його завдання.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("""
  SELECT u.*, t.*
  FROM users u
  INNER JOIN tasks t ON u.id = t.user_id
  INNER JOIN status s ON t.status_id = s.id
  WHERE s.name = 'in progress'
  """)
  rows = cur.fetchall()
  cur.close()
  return rows

def get_users_with_task_count(conn):
  """
  Отримати користувачів та кількість їхніх завдань.

  Args:
    conn: Об'єкт підключення до бази даних.

  Returns:
    Список словників, де кожен словник містить інформацію про користувача та кількість його завдань.
  """
  rows = None
  cur = conn.cursor()
  cur.execute("""
  SELECT u.*, COUNT(t.id) AS task_count
  FROM users u
  LEFT JOIN tasks t ON u.id = t.user_id
  GROUP BY u.id
  """)
  rows = cur.fetchall()
  cur.close()
  return rows
